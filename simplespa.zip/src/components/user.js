import {Component} from 'react';

export default class User extends Component {
    render(){
        return(
            <div>
                This is a User page.
            </div>
        );
    }
}